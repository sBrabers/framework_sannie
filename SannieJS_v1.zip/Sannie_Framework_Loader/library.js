
const spinner = document.getElementsByClassName("spinner")[0];
const overlay = document.getElementById("overlay");
window.addEventListener('load', () => {
  overlay.style.display = 'none';
});

overlay.setAttribute("style", "background:rgba(0, 0, 0, 0,8); heigth: 100%; width: 100%; position: fixed; left:0; top:0;");

overlay.style.background = "0,0,0,0,8";
overlay.style.height = "100%";
overlay.style.width = "100%";
overlay.style.position = "fixed";
overlay.style.left = "0";
overlay.style.top = "0";

spinner.style.borderTop = "";